######################### file/path/package ######################################
rm(list = ls())
path <- "Z:/eBay/Item Delivery tpNPS/Coder/Reporting/WIP/5_May'17"
setwd(path)
save.image("Z:/eBay/Item Delivery tpNPS/Coder/Reporting/WIP/Apr'17_Report/itmdel_apr'17.RData")
load(file = "itmdel_mar'17")

install.packages("LearnBayes", dependencies = T)

library(readr)
library(dplyr)
library(lubridate)
library(zoo)
library(QuantPsyc)
library(plyr)
library(reshape2)
library(reshape)
library(data.table)
library(LearnBayes)

######################### data_handler ######################################

print(ls())
class(df$trigger_dt) - #finding class 
dfa$dfb <- NULL - #remove data
dfa <- NULL - #remove data
View(df) - #viewing data
names(df) - #variable names
describe(df$FAST_N_FREE_YN_IND) - #frequency disttibution
cumsum(df$Rcvd_when_prmsd) - #cumulative frequency distribution
table(df$FAST_N_FREE_YN_IND) - #frequency distribution of a categorical variable
df= rename(df, variable1=var1) - #rename variable
trimws() - #remove leading and trailing spaces

start.time <- Sys.time() - #measure execution time of a program
runif(5555,1,1000)
end.time <- Sys.time()
end.time - start.time

OR

library(tictoc)
tic()
runif(5555,1,1000)
toc()

library(dplyr) - #Drop Multiple Variables
df = select(mydata, -c(x,y,z))
find_funs("filter") #source("https://sebastiansauer.github.io/Rcode/find_funs.R")
library(scales)  # for percentage scales
######################### script ######################################

##upload##
df <- read_csv("Z:/eBay/Item Delivery tpNPS/Coder/Reporting/WIP/5_May'17/Blueocean_Verbatim_May_2017_Delivery_TP_dataset.csv")

##upload restructured data##
df <- read_csv("Z:/eBay/Item Delivery tpNPS/Coder/Reporting/WIP/5_May'17/may'17_itm_del_restructured.csv")

##create month & year##
Month <- strptime(df$trigger_dt, "%m/%d/%Y")
df$Months <- format(Month, "%b'%y")
#or
df$Months <- format(Month, "%y-%b")

##create quarter & year##
df$Quarter=as.yearqtr(df$trigger_dt,"%m/%d/%Y")
df$Quarter=as.yearqtr(as.Date( df$trigger_dt, "%m/%d/%Y" ))

##recode SAP_GLBL_NAME_2##
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Coins'] <- 'Collectibles and Art' 
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Books'] <- 'Collectibles and Art'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Collectibles'] <- 'Collectibles and Art'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Sports Memorabilia'] <- 'Collectibles and Art'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Hobbies & Crafts'] <- 'Collectibles and Art'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Entertainment Memorabilia'] <- 'Collectibles and Art'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Music'] <- 'Collectibles and Art'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Photo'] <- 'Collectibles and Art'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Antiques'] <- 'Collectibles and Art'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Art'] <- 'Collectibles and Art'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Stamps'] <- 'Collectibles and Art'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Pottery & Glass'] <- 'Collectibles and Art'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Tickets'] <- 'Collectibles and Art'

df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Auto - Parts'] <- 'Automotive Parts & Accessories'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Travel'] <- 'Automotive Parts & Accessories'

df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Baby'] <- 'Children & Baby Products'

df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Jewelry, Gems, Watches'] <- 'Clothing, Shoes, & Accessories'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Clothing & Accessories'] <- 'Clothing, Shoes, & Accessories'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Health & Beauty'] <- 'Clothing, Shoes, & Accessories'

df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Business (Office & Industrial)'] <- 'Business (Office & Industrial)'

df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Cell Phones & Accessories'] <- 'Electronics and Computers'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Computers'] <- 'Electronics and Computers'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Telecomm'] <- 'Electronics and Computers'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Consumer Electronics - Video'] <- 'Electronics and Computers'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Consumer Electronics - Other'] <- 'Electronics and Computers'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Musical Instruments'] <- 'Electronics and Computers'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Consumer Electronics - Audio'] <- 'Electronics and Computers'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Home Appliances'] <- 'Electronics and Computers'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Video Games'] <- 'Electronics and Computers'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'DVDs & Movies'] <- 'Electronics and Computers'

df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Home Improvement'] <- 'Home & Garden'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Home Furnishing'] <- 'Home & Garden'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Food & Gourmet'] <- 'Home & Garden'

df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Sporting Goods'] <- 'Sporting Goods'

df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Toys'] <- 'Toys & Hobbies'
df$SAP_GLBL_NAME_2[df$SAP_GLBL_NAME == 'Dolls & Bears'] <- 'Toys & Hobbies'
  
##rename FREE_SHPNG_YN_IND##
df$FREE_SHPNG_YN_IND_2[df$FREE_SHPNG_YN_IND == 'Y'] <- 'Yes'
df$FREE_SHPNG_YN_IND_2[df$FREE_SHPNG_YN_IND == 'N'] <- 'No'

##rename FAST_N_FREE_YN_IND##
df$FAST_N_FREE_YN_IND_2[df$FAST_N_FREE_YN_IND == 'Y'] <- 'Yes'
df$FAST_N_FREE_YN_IND_2[df$FAST_N_FREE_YN_IND == 'N'] <- 'No'

##recode SPE_ACT_HT_FULFLD##
df$SPE_ACT_HT_FULFLD_2[df$SPE_ACT_HT_FULFLD == '1 DAY EARLY'] <- 'Early'
df$SPE_ACT_HT_FULFLD_2[df$SPE_ACT_HT_FULFLD == '2 OR MORE DAYS EARLY'] <- 'Early'
df$SPE_ACT_HT_FULFLD_2[df$SPE_ACT_HT_FULFLD == '1 DAY LATE'] <- 'Late'
df$SPE_ACT_HT_FULFLD_2[df$SPE_ACT_HT_FULFLD == '2 OR MORE DAYS LATE'] <- 'Late'
df$SPE_ACT_HT_FULFLD_2[df$SPE_ACT_HT_FULFLD == 'EXACT HANDLING'] <- 'On Time'
df$SPE_ACT_HT_FULFLD_2[df$SPE_ACT_HT_FULFLD == '?'] <- ''

##recode PROM_ACT_DELIV##
df$PROM_ACT_DELIV_2[df$PROM_ACT_DELIV == '2 DAYS EARLY'] <- 'Early'
df$PROM_ACT_DELIV_2[df$PROM_ACT_DELIV == '3 OR MORE DAYS EARLY'] <- 'Early'
df$PROM_ACT_DELIV_2[df$PROM_ACT_DELIV == '1 DAY EARLY'] <- 'Early'
df$PROM_ACT_DELIV_2[df$PROM_ACT_DELIV == '2 - 5 DAYS LATE'] <- 'Late'
df$PROM_ACT_DELIV_2[df$PROM_ACT_DELIV == '1 DAY LATE'] <- 'Late'
df$PROM_ACT_DELIV_2[df$PROM_ACT_DELIV == '5+ DAYS LATE'] <- 'Late'
df$PROM_ACT_DELIV_2[df$PROM_ACT_DELIV == 'EXACT'] <- 'On Time'
df$PROM_ACT_DELIV_2[df$PROM_ACT_DELIV == '?'] <- ''

##recode LABEL_TRANS##
df$LABEL_TRANS_2[df$LABEL_TRANS == '1'] <- 'Labeled'
df$LABEL_TRANS_2[df$LABEL_TRANS == '0'] <- 'Non-Labeled'

##recode CBT_YN_IND##
df$CBT_YN_IND_2[df$CBT_YN_IND == 'Y'] <- 'Yes'
df$CBT_YN_IND_2[df$CBT_YN_IND == 'N'] <- 'No'

##recode FM_BYR_SGMNTN_DESC##
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'Frequent Low/Mid Spenders'] <- 'Frequent Spenders'
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'Frequent High Spenders'] <- 'Frequent Spenders'
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'Infrequent Low Spenders'] <- 'Infrequent Spenders'
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'Infrequent Mid Spenders'] <- 'Infrequent Spenders'
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'Infrequent High Spenders'] <- 'Infrequent Spenders'
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'New'] <- 'New'
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'Reactivated'] <- 'Reactivated'
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'Uber Loyals'] <- 'Uber Loyals'
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'Unengaged'] <- 'Unengaged'
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'NA'] <- ''
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'Unsegmented'] <- ''
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'Lapsed'] <- ''
df$FM_BYR_SGMNTN_DESC_2[df$FM_BYR_SGMNTN_DESC == 'Dormant'] <- ''

##recode ITM_CNDTN##
df$ITM_CNDTN_2[df$ITM_CNDTN == 'NEW'] <- 'New'
df$ITM_CNDTN_2[df$ITM_CNDTN == 'NOT SPECIFIED'] <- ''
df$ITM_CNDTN_2[df$ITM_CNDTN == 'REFURBISHED'] <- 'Used/Refurbished'
df$ITM_CNDTN_2[df$ITM_CNDTN == 'UNKNOWN'] <- ''
df$ITM_CNDTN_2[df$ITM_CNDTN == 'USED'] <- 'Used/Refurbished'

##recode mrtl_status_cd##
df$mrtl_status_cd_2[df$mrtl_status_cd == 'S'] <- 'Single'
df$mrtl_status_cd_2[df$mrtl_status_cd == 'A'] <- 'Inf_Married'
df$mrtl_status_cd_2[df$mrtl_status_cd == 'M'] <- 'Married'
df$mrtl_status_cd_2[df$mrtl_status_cd == 'B'] <- 'Inf_Single'
df$mrtl_status_cd_2[df$mrtl_status_cd == '?'] <- ''
df$mrtl_status_cd_2[df$mrtl_status_cd == 'N'] <- ''

##recode TRKING_SRC_CRE_DT##
df$TRKING_SRC_CRE_DT_2 <- ifelse(df$TRKING_SRC_CRE_DT == '?', "Non-Tracked",  "Tracked")

##recode ITEM_PRICE_AMT##
df$ITEM_PRICE_AMT_2 <- ifelse(df$ITEM_PRICE_AMT >= 0.01 & df$ITEM_PRICE_AMT <= 49.99, "$0.01-49.99", 
                       ifelse(df$ITEM_PRICE_AMT >= 50 & df$ITEM_PRICE_AMT <= 449.99, "$50-449.99",
                       "$450+"))

##recode SHPNG_FEE_AMT##
df$SHPNG_FEE_AMT_2 <- ifelse(df$SHPNG_FEE_AMT == 0, "$0", 
                      ifelse(df$SHPNG_FEE_AMT >= 0.01 & df$SHPNG_FEE_AMT <= 4.99, "$0.01-4.99",
                      ifelse(df$SHPNG_FEE_AMT >= 5 & df$SHPNG_FEE_AMT <= 9.99, "$5-9.99",
                      "$10+")))

##recode NSAT##
df$NPS <- ifelse(df$tp_sat <= 6,-1,
                 ifelse((df$tp_sat == 7 | df$tp_sat == 8),0,
                        ifelse(df$tp_sat > 8,1,NA)))

##rename NPS##
df$NPS2[df$NPS == '-1'] <- 'Det'
df$NPS2[df$NPS == '0'] <- 'Pass'
df$NPS2[df$NPS == '1'] <- 'Prom'

##recode DELIV_TIME_BUCKET##
df$DELIV_TIME_BUCKET_2[df$DELIV_TIME_BUCKET == '0 DAY DELIV'] <- '<=2 Days'
df$DELIV_TIME_BUCKET_2[df$DELIV_TIME_BUCKET == '1 DAY DELIV'] <- '<=2 Days'
df$DELIV_TIME_BUCKET_2[df$DELIV_TIME_BUCKET == '2 DAY DELIV'] <- '<=2 Days'
df$DELIV_TIME_BUCKET_2[df$DELIV_TIME_BUCKET == 'DELIV BEFORE TIME'] <- '<=2 Days'
df$DELIV_TIME_BUCKET_2[df$DELIV_TIME_BUCKET == '3 DAY DELIV'] <- '3-4 Days'
df$DELIV_TIME_BUCKET_2[df$DELIV_TIME_BUCKET == '4 DAY DELIV'] <- '3-4 Days'
df$DELIV_TIME_BUCKET_2[df$DELIV_TIME_BUCKET == '5 DAY DELIV'] <- '5 Days'
df$DELIV_TIME_BUCKET_2[df$DELIV_TIME_BUCKET == '6 DAY DELIV'] <- '6+ Days'
df$DELIV_TIME_BUCKET_2[df$DELIV_TIME_BUCKET == '7+ DAY DELIV'] <- '6+ Days'
df$DELIV_TIME_BUCKET_2[df$DELIV_TIME_BUCKET == 'UNKNOWN'] <- ' '

##recode NSAT##
df$USER_AGE_2 <- ifelse(df$USER_AGE >= 15 & df$USER_AGE <= 24, "15-24", 
                 ifelse(df$USER_AGE >= 25 & df$USER_AGE <= 44, "25-44",
                 ifelse(df$USER_AGE >= 45 & df$USER_AGE <= 64, "45-64",
                 ifelse(df$USER_AGE >= 65,"65+", "?"))))

write.csv(df, "Z:/eBay/Item Delivery tpNPS/Coder/Reporting/WIP/5_May'17/may'17_itm_del_restructured.csv", row.names = F)

##########################################################

### NPS Calc slide#3 ###
round(mean(df$NPS)*100,2) 


### PPD_% Calc slide#3 ###
y = xtabs(~ NPS2 + NPS2, df)
y
z <- data.frame(y)
z[1,"nps"] <- round(z[1,2]/sum(z$Freq)*100,2)
z[2,"nps"] <- round(z[2,2]/sum(z$Freq)*100,2)
z[3,"nps"] <- round(z[3,2]/sum(z$Freq)*100,2)
z


###tp_sat% Calc slide#3 ###
y = xtabs(~ tp_sat + tp_sat, df)
y
z <- data.frame(y)
z[1,"nps"] <- round(z[1 ,2]/sum(z$Freq)*100,2)
z[2,"nps"] <- round(z[2 ,2]/sum(z$Freq)*100,2)
z[3,"nps"] <- round(z[3 ,2]/sum(z$Freq)*100,2)
z[4,"nps"] <- round(z[4 ,2]/sum(z$Freq)*100,2)
z[5,"nps"] <- round(z[5 ,2]/sum(z$Freq)*100,2)
z[6,"nps"] <- round(z[6 ,2]/sum(z$Freq)*100,2)
z[7,"nps"] <- round(z[7 ,2]/sum(z$Freq)*100,2)
z[8,"nps"] <- round(z[8 ,2]/sum(z$Freq)*100,2)
z[9,"nps"] <- round(z[9 ,2]/sum(z$Freq)*100,2)
z[10,"nps"] <- round(z[10 ,2]/sum(z$Freq)*100,2)
z[11,"nps"] <- round(z[11 ,2]/sum(z$Freq)*100,2)
z


### regression - overall ###
reg <-  lm(tp_sat ~ Rcvd_when_prmsd+Shp_fast+Shp_charges_rsnbl+Pckgd_well, data = df)
summary(reg)
regression <- lm.beta(reg)
View(regression)

names(df)

#### pivot with count and nsat ####
dfa = dcast(df, PROM_ACT_DELIV_2 ~ NPS2)
dfa
dfa$total = with(dfa, Det+Pass+Prom)
dfa$detpct = (dfa$Det / dfa$total)*100
dfa$passpct = (dfa$Pass / dfa$total)*100
dfa$prompct = (dfa$Prom / dfa$total)*100
dfa$nsat <- round((dfa$prompct - dfa$detpct),2)
dfa
View(dfa)
###################################

###################################################

dfa = dcast(df, PRDCTV_GNDR + MBL_DVIC_NAME ~ NPS2, subset=.(PRDCTV_GNDR == "M"))

dfa = dcast(df, PRDCTV_GNDR + MBL_DVIC_NAME ~ NPS2)
dfa
dfa$total = with(dfa, Det+Pass+Prom)
dfa$detpct = (dfa$Det / dfa$total)*100
dfa$passpct = (dfa$Pass / dfa$total)*100
dfa$prompct = (dfa$Prom / dfa$total)*100
dfa$nsat <- round((dfa$prompct - dfa$detpct),2)
View(dfa)

###################################################
## geom_bar chart

library(dplyr)
summary = ExampleM %>% group_by(Year, variable, value) %>%
  tally %>%
  group_by(Year, variable) %>%
  mutate(pct = n/sum(n),
         n.pos = cumsum(n) - 0.5*n)

ggplot(summary, aes(x=variable, y=n, fill=value)) +
  geom_bar(stat="identity") +
  facet_grid(.~Year) + 
  geom_text(aes(label=paste0(sprintf("%1.1f", pct*100),"%"), y=n.pos), 
            colour="white") 

###################################################
dfa = dcast(df, PROM_ACT_DELIV_2 ~ NPS)
dfa.sum <- colSums(dfa)

dfa$Pct <- dfa$Total / sum(dfa$Total)

######
dfa = dcast(df, USER_AGE_2 ~ NPS2)
dfa
dfa$total = with(dfa, Det+Pass+Prom)
dfa$detpct = (dfa$Det / dfa$total)*100
dfa$passpct = (dfa$Pass / dfa$total)*100
dfa$prompct = (dfa$Prom / dfa$total)*100
dfa$nsat <- round(dfa$prompct - dfa$detpct)
View(dfa)
######

names(df)

  
y = xtabs(~ NPS2 + PROM_ACT_DELIV_2, df)
View(y)
z <- data.frame(y)
View(z)

prom <- round(z[1,2]/sum(z$Freq)*100)
pass <- round(z[2,2]/sum(z$Freq)*100)
det <- round(z[3,2]/sum(z$Freq)*100)

prom
pass
det

########
dfa = dcast(df, PROM_ACT_DELIV_2 ~ NPS, value.var = summarise(dfa))
dfa

View(df)

dff <- cast(df, PROM_ACT_DELIV_2 ~ NPS, sum)
dff
dff <- cast(df, NPS ~ PROM_ACT_DELIV_2, sum, margins=c("grand_row"))

df1 <- ddply(df, .(PROM_ACT_DELIV_2), summarise, NPS = NPS, pct = NPS / sum(NPS))
df1
dfc <- cast(df1, PROM_ACT_DELIV_2 ~ NPS)
dfc

a <- prop.table(tapply(df$NPS, df[1:2], sum), 1)
a

prop.table( xtabs(PROM_ACT_DELIV_2 ~., df$NPS), 1 )



df %>%
  group_by(PROM_ACT_DELIV_2, NPS) %>%
  summarise(n = n())

df %>%
  group_by(PROM_ACT_DELIV_2, NPS) %>%
  summarise (n = n()) %>%
  mutate(freq = n / sum(n))

df %>%
  count(df$PROM_ACT_DELIV_2, df$NPS) %>%
  mutate(freq = n / sum(n))

df %>%
  count(df$PROM_ACT_DELIV_2, NPS) %>%
  mutate(freq = n / sum(n)) %>%
  ungroup()

library(dplyr)
install.packages("dtplyr", dependencies = T)
library(dtplyr)
data(mtcars)
mtcars = tbl_dt(mtcars)

mtcars %>%
  group_by(am, gear) %>%
  summarise(n = n())

dat <- data.frame(Operation = c("Login", "Posted", "Deleted"), `Total.Count` = c(5, 25, 40), check.names = FALSE)
dat
dat$Pct <- dat$Total.Count / sum(dat$Total.Count)
dat



library(data.table)    
cbind(dfa, dfa[,list(sum=-1+0+1)])


dfa %>%
  group_by(PROM_ACT_DELIV_2) %>%
  summarise(Sum=sum(value))



is.data.table(dfa)== TRUE


